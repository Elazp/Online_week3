 




function commands(arrayofcom){
	var myRover = {
  	position: [0,0], 
  	direction: 'N'
	}
	
console.log(myRover.position)	
	if (myRover.position == [8,0]){
		console.log('Obstáculo en el camino. Posición'+ myRover.position)}
	
console.log(myRover.position)
}

commands('fffrfflfff');
